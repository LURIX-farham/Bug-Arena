# چک‌لیست استقرار Bug Arena روی هاست اشتراکی

> نسخه: 1.0 · مربوط به پروژه BugArena v1.9.0 (فرانت React/Vite + بک‌اند PHP + MySQL)

## مرحله ۰ — پیش‌نیازهای هاست
- [ ] PHP **8.1 یا بالاتر** (توصیه: 8.2/8.3) — کد از readonly و never استفاده می‌کند
- [ ] MySQL 5.7+ یا MariaDB 10.4+ با utf8mb4
- [ ] افزونه‌های فعال: `pdo_mysql`, `mbstring`, `json`
- [ ] mod_rewrite فعال و `AllowOverride All` (پیش‌فرض cPanel)
- [ ] SSL فعال برای دامنه (Let's Encrypt / AutoSSL)
- [ ] گزینه «Cron/SSH» لازم نیست؛ هرچیزی از طریق cPanel انجام می‌شود

## مرحله ۱ — ساخت دیتابیس
- [ ] cPanel → MySQL Databases → ساخت دیتابیس `..._bug_arena`
- [ ] ساخت کاربر دیتابیس با **رمز قوی** (Generate در خود cPanel)
- [ ] افزودن کاربر به دیتابیس با دسترسی **ALL PRIVILEGES**
- [ ] phpMyAdmin → Import → `backend/database/schema.sql`
- [ ] (اختیاری) Import → `backend/database/seed_challenges.sql` برای چالش‌های اولیه

## مرحله ۲ — بیلد فرانت‌اند (روی سیستم خودت)
- [ ] `npm ci`
- [ ] بیلد با آدرس API صحیح:
  ```bash
  VITE_API_BASE_URL=/api npm run build
  ```
  خروجی: پوشه `dist/`
- [ ] کنترل: در `dist/assets/*.js` رشته‌ی `localhost/BugArena` نباید وجود داشته باشد

## مرحله ۳ — آپلود
- [ ] محتویات `dist/` → `public_html/` (نه خود پوشه dist؛ محتویاتش)
- [ ] محتویات `backend/` → `public_html/api/`
  - شامل: `public/`, `src/`, `routes/`, `config/`, `database/`, `logs/` (خالی)
- [ ] `deploy/public_html.htaccess` → به `public_html/.htaccess` تغییر نام بده
- [ ] `deploy/api.htaccess` → به `public_html/api/.htaccess` تغییر نام بده
- [ ] `deploy/.env.production.example` → مقادیر واقعی → آپلود به `public_html/.env`
- [ ] **آپلود نکن:** `setup.php`, `test_api.php`, `test-cli.php`, پوشه `scripts/`
  (اگر آپلود شدند هم .htaccess جلویشان را می‌گیرد — اما نباید اصلاً باشند)

## مرحله ۴ — دسترسی‌ها
- [ ] پوشه `public_html/api/logs` : قابل‌نوشتن (۷۷۵) — PHP باید بتواند لاگ بنویسد
- [ ] بقیه فایل‌ها: ۶۴۴ / پوشه‌ها: ۷۵۵ (پیش‌فرض File Manager)
- [ ] فایل `.env` : ۶۰۰ یا ۶۴۴ (از وب قابل خواندن نیست چون dotfile بلاک است)

## مرحله ۵ — تست سلامت (به ترتیب!)
- [ ] `https://دامنه/api/` → پاسخ JSON: `{"ok":true,...}` (یعنی PHP و DB زنده‌اند)
- [ ] `https://دامنه/` → صفحه لندینگ سبز Bug Arena لود شود
- [ ] ثبت‌نام کاربر جدید → ورود → چالش → ثبت کد → امتیاز
- [ ] F12 → تب Network → هیچ درخواستی به `localhost` نرود
- [ ] `https://دامنه/.env` → خطای 403 (یعنی محافظت کار می‌کند)
- [ ] `https://دامنه/api/setup.php` → خطای 403

## مرحله ۶ — پس از استقرار
- [ ] فعال‌کردن HSTS در `public_html/.htaccess` (خط کامنت‌شده را باز کن)
- [ ] بکاپ خودکار دیتابیس را در cPanel فعال کن (هفتگی حداقل)
- [ ] نسخه PHP را روی آخرین نسخه پایدار 8.x نگه دار
- [ ] ماهی یک‌بار لاگ `api/logs/api-*.log` را برای خطاهای مشکوک ببین
