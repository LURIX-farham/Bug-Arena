<?php
declare(strict_types=1);

namespace BugArena\Services;

/**
 * Sandboxed-ish Python test runner for challenge evaluation on the server.
 * Uses a short-lived subprocess with a hard wall-clock limit.
 */
final class PythonRunner
{
    private const DEFAULT_TIMEOUT_SEC = 8;
    private const MAX_OUTPUT_BYTES = 512_000;

    /**
     * @param array<int, array{id?:mixed,name?:string,type?:string,args?:array,expected?:mixed}> $tests
     * @return array{
     *   ok:bool,
     *   status:string,
     *   error:?string,
     *   wallMs:int,
     *   results:array<int, array<string,mixed>>,
     *   testsPassed:int,
     *   testsTotal:int,
     *   corePassed:bool,
     *   hiddenPassed:bool,
     *   allPassed:bool,
     *   authoritative:bool,
     *   source:string
     * }
     */
    public static function run(string $code, string $functionName, array $tests, int $timeoutSec = self::DEFAULT_TIMEOUT_SEC): array
    {
        $started = hrtime(true);
        $empty = static function (string $status, string $error) use ($tests, $started): array {
            $wallMs = (int) max(0, (hrtime(true) - $started) / 1_000_000);
            $results = [];
            foreach ($tests as $test) {
                $results[] = [
                    'id' => $test['id'] ?? null,
                    'name' => $test['name'] ?? 'test',
                    'type' => $test['type'] ?? 'core',
                    'status' => 'failed',
                    'actual' => null,
                    'error' => $error,
                ];
            }
            return [
                'ok' => false,
                'status' => $status,
                'error' => $error,
                'wallMs' => $wallMs,
                'results' => $results,
                'testsPassed' => 0,
                'testsTotal' => count($tests),
                'corePassed' => false,
                'hiddenPassed' => false,
                'allPassed' => false,
                'authoritative' => true,
                'source' => 'server',
            ];
        };

        if ($functionName === '') {
            return $empty('execution_error', 'function_name_missing');
        }
        if ($tests === []) {
            return $empty('execution_error', 'no_tests');
        }
        if (!function_exists('proc_open')) {
            return $empty('execution_error', 'proc_open_disabled');
        }

        $binary = self::findPythonBinary();
        if ($binary === null) {
            return $empty('execution_error', 'python_not_found');
        }

        $harness = <<<'PY'
import json, sys, math

payload = json.load(sys.stdin)
namespace = {}
try:
    exec(payload["code"], namespace, namespace)
except Exception as exc:
    print(json.dumps({"ok": False, "error": f"compile_error: {exc}", "results": []}))
    sys.exit(0)

fn = namespace.get(payload["function_name"])
if not callable(fn):
    print(json.dumps({"ok": False, "error": f"function_not_found: {payload['function_name']}", "results": []}))
    sys.exit(0)

def normalize(value):
    if isinstance(value, bool):
        return value
    if isinstance(value, int):
        return value
    if isinstance(value, float):
        if math.isnan(value) or math.isinf(value):
            return str(value)
        # Treat whole-number floats as ints for comparison stability.
        if abs(value - round(value)) < 1e-9:
            return int(round(value))
        return round(value, 10)
    if isinstance(value, (list, tuple)):
        return [normalize(v) for v in value]
    if isinstance(value, dict):
        return {str(k): normalize(v) for k, v in sorted(value.items(), key=lambda kv: str(kv[0]))}
    return value

def deep_equal(left, right):
    try:
        return json.dumps(normalize(left), sort_keys=True, ensure_ascii=False) == json.dumps(normalize(right), sort_keys=True, ensure_ascii=False)
    except Exception:
        return left == right

results = []
for test in payload.get("tests", []):
    entry = {
        "id": test.get("id"),
        "name": test.get("name") or "test",
        "type": test.get("type") or "core",
        "status": "failed",
        "actual": None,
        "error": None,
    }
    try:
        args = test.get("args") or []
        if not isinstance(args, list):
            args = [args]
        actual = fn(*args)
        expected = test.get("expected")
        entry["actual"] = actual
        if deep_equal(actual, expected):
            entry["status"] = "passed"
        else:
            entry["error"] = "assertion_failed"
    except Exception as exc:
        entry["error"] = str(exc)
    results.append(entry)

print(json.dumps({"ok": True, "error": None, "results": results}, ensure_ascii=False, default=str))
PY;

        $payload = json_encode([
            'code' => $code,
            'function_name' => $functionName,
            'tests' => array_values(array_map(static function (array $t): array {
                return [
                    'id' => $t['id'] ?? null,
                    'name' => $t['name'] ?? 'test',
                    'type' => $t['type'] ?? 'core',
                    'args' => $t['args'] ?? [],
                    'expected' => $t['expected'] ?? null,
                ];
            }, $tests)),
        ], JSON_UNESCAPED_UNICODE);

        if ($payload === false) {
            return $empty('execution_error', 'invalid_payload');
        }

        $descriptors = [
            0 => ['pipe', 'r'],
            1 => ['pipe', 'w'],
            2 => ['pipe', 'w'],
        ];
        $cmd = [$binary, '-c', $harness];
        $proc = @proc_open($cmd, $descriptors, $pipes, null, null, ['bypass_shell' => true]);
        if (!is_resource($proc)) {
            return $empty('execution_error', 'proc_open_failed');
        }

        stream_set_blocking($pipes[0], true);
        fwrite($pipes[0], $payload);
        fclose($pipes[0]);

        $timeoutSec = max(1, min(20, $timeoutSec));
        $deadline = microtime(true) + $timeoutSec;
        stream_set_blocking($pipes[1], false);
        stream_set_blocking($pipes[2], false);

        $stdout = '';
        $stderr = '';
        $timedOut = false;

        while (true) {
            $status = proc_get_status($proc);
            $stdout .= stream_get_contents($pipes[1]) ?: '';
            $stderr .= stream_get_contents($pipes[2]) ?: '';
            if (strlen($stdout) + strlen($stderr) > self::MAX_OUTPUT_BYTES) {
                $timedOut = true;
                break;
            }
            if (!$status['running']) {
                break;
            }
            if (microtime(true) >= $deadline) {
                $timedOut = true;
                break;
            }
            usleep(20_000);
        }

        if ($timedOut) {
            proc_terminate($proc, 9);
            proc_close($proc);
            return $empty('timeout', 'execution_timeout');
        }

        // Drain remaining
        $stdout .= stream_get_contents($pipes[1]) ?: '';
        $stderr .= stream_get_contents($pipes[2]) ?: '';
        fclose($pipes[1]);
        fclose($pipes[2]);
        proc_close($proc);

        $wallMs = (int) max(0, (hrtime(true) - $started) / 1_000_000);
        $line = trim($stdout);
        // Take last non-empty line in case of warnings
        if (str_contains($line, "\n")) {
            $parts = array_values(array_filter(array_map('trim', explode("\n", $line)), static fn ($l) => $l !== ''));
            $line = $parts !== [] ? $parts[array_key_last($parts)] : $line;
        }

        $decoded = json_decode($line, true);
        if (!is_array($decoded)) {
            $msg = trim($stderr) !== '' ? substr(trim($stderr), 0, 300) : 'invalid_runner_output';
            return $empty('execution_error', $msg);
        }
        if (empty($decoded['ok'])) {
            return $empty('execution_error', (string) ($decoded['error'] ?? 'execution_error'));
        }

        $results = [];
        $passed = 0;
        foreach (($decoded['results'] ?? []) as $row) {
            if (!is_array($row)) {
                continue;
            }
            $status = ($row['status'] ?? '') === 'passed' ? 'passed' : 'failed';
            if ($status === 'passed') {
                $passed++;
            }
            $results[] = [
                'id' => $row['id'] ?? null,
                'name' => $row['name'] ?? 'test',
                'type' => $row['type'] ?? 'core',
                'status' => $status,
                'actual' => $row['actual'] ?? null,
                'error' => $row['error'] ?? null,
            ];
        }

        $core = array_values(array_filter($results, static fn ($r) => ($r['type'] ?? '') === 'core'));
        $hidden = array_values(array_filter($results, static fn ($r) => ($r['type'] ?? '') === 'hidden'));
        $corePassed = $core !== [] && array_reduce($core, static fn ($ok, $r) => $ok && $r['status'] === 'passed', true);
        $hiddenPassed = $hidden === [] || array_reduce($hidden, static fn ($ok, $r) => $ok && $r['status'] === 'passed', true);

        return [
            'ok' => true,
            'status' => $corePassed ? ($hiddenPassed ? 'passed' : 'partial') : 'failed',
            'error' => $corePassed ? null : 'tests_failed',
            'wallMs' => $wallMs,
            'results' => $results,
            'testsPassed' => $passed,
            'testsTotal' => count($results),
            'corePassed' => $corePassed,
            'hiddenPassed' => $hiddenPassed,
            'allPassed' => $corePassed && $hiddenPassed,
            'authoritative' => true,
            'source' => 'server',
        ];
    }

    private static function findPythonBinary(): ?string
    {
        $candidates = ['python3', 'python', '/usr/bin/python3', '/usr/local/bin/python3', '/usr/bin/python'];
        foreach ($candidates as $bin) {
            // which via command -v is shell; use is_executable for absolute paths
            if (str_contains($bin, '/')) {
                if (is_executable($bin)) {
                    return $bin;
                }
                continue;
            }
            // Try running --version with proc_open briefly
            if (!function_exists('proc_open')) {
                continue;
            }
            $descriptors = [0 => ['pipe', 'r'], 1 => ['pipe', 'w'], 2 => ['pipe', 'w']];
            $proc = @proc_open([$bin, '--version'], $descriptors, $pipes, null, null, ['bypass_shell' => true]);
            if (!is_resource($proc)) {
                continue;
            }
            fclose($pipes[0]);
            $out = stream_get_contents($pipes[1]) ?: '';
            $err = stream_get_contents($pipes[2]) ?: '';
            fclose($pipes[1]);
            fclose($pipes[2]);
            $code = proc_close($proc);
            if ($code === 0 || str_contains($out . $err, 'Python')) {
                return $bin;
            }
        }
        return null;
    }
}
